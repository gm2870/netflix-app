/**
 * @internal
 */
export declare const packageVersion = "20.5.0";
//# sourceMappingURL=version.d.ts.map